import numpy as np
import pytest
from fuzzycred_hqcm.fuzzycred import triangular_memberships, credibility_features, FuzzyCredMetaLearner


def test_memberships_are_bounded_and_shape_is_stable():
    p = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
    m = triangular_memberships(p)
    assert m.shape == (5, 3)
    assert np.isfinite(m).all()
    assert ((m >= 0) & (m <= 1)).all()
    np.testing.assert_allclose(m[0], [1, 0, 0])
    np.testing.assert_allclose(m[2], [0, 1, 0])
    np.testing.assert_allclose(m[4], [0, 0, 1])


def test_credibility_features_capture_disagreement():
    x = credibility_features(np.array([0.1, 0.9]), np.array([0.1, 0.2]))
    assert x.shape == (2, 11)
    np.testing.assert_allclose(x[:, 8], [0.0, 0.7])


def test_meta_learner_fits_oof_probabilities():
    rng = np.random.default_rng(4)
    y = np.tile([0, 1], 100)
    pc = np.clip(0.15 + 0.7 * y + rng.normal(0, 0.08, len(y)), 0, 1)
    pq = np.clip(0.2 + 0.6 * y + rng.normal(0, 0.12, len(y)), 0, 1)
    model = FuzzyCredMetaLearner(random_state=7).fit(pc, pq, y)
    pred = model.predict_proba(pc, pq)
    assert pred.shape == y.shape
    assert np.isfinite(pred).all()
    assert ((pred >= 0) & (pred <= 1)).all()


def test_invalid_probabilities_rejected():
    with pytest.raises(ValueError):
        triangular_memberships(np.array([0.2, 1.2]))
