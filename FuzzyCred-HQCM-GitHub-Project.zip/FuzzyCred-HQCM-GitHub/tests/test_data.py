from fuzzycred_hqcm.data import make_mi_target, parse_scp_codes


def test_target_uses_selected_mi_subclasses():
    assert make_mi_target("{'AMI': 100}") == 1
    assert make_mi_target("{'IMI': 100}") == 1
    assert make_mi_target("{'LMI': 100}") == 1
    assert make_mi_target("{'PMI': 100}") == 1
    assert make_mi_target("{'NORM': 100}") == 0
    assert make_mi_target("not a dictionary") == 0


def test_parser_does_not_execute_invalid_values():
    assert parse_scp_codes("__import__('os').system('echo unsafe')") == {}
