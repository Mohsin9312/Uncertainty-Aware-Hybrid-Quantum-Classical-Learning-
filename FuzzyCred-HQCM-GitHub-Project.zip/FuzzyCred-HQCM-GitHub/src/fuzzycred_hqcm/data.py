"""PTB-XL+ feature loading, target construction, and split integrity checks."""
from __future__ import annotations
import ast
from pathlib import Path
import numpy as np
import pandas as pd

MI_SUBCLASSES = frozenset({"AMI", "IMI", "LMI", "PMI"})
REQUIRED_FILES = {
    "ptbxl_database.csv": {"ecg_id", "patient_id", "strat_fold"},
    "ptbxl_statements.csv": {"ecg_id", "scp_codes"},
    "12sl_features.csv": {"ecg_id"},
    "unig_features.csv": {"ecg_id"},
}


def parse_scp_codes(value: object) -> dict:
    """Parse a PTB-XL ``scp_codes`` cell without executing arbitrary code."""
    if isinstance(value, dict):
        return value
    if not isinstance(value, str):
        return {}
    try:
        result = ast.literal_eval(value)
    except (ValueError, SyntaxError):
        return {}
    return result if isinstance(result, dict) else {}


def make_mi_target(value: object) -> int:
    """Return 1 if AMI, IMI, LMI, or PMI is present in the SCP-code keys."""
    return int(bool(MI_SUBCLASSES.intersection(parse_scp_codes(value).keys())))


def _read_checked(path: Path, required: set[str]) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Required input file not found: {path}")
    frame = pd.read_csv(path)
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"{path.name} is missing required columns: {sorted(missing)}")
    if frame["ecg_id"].isna().any():
        raise ValueError(f"{path.name} contains null ecg_id values")
    if frame["ecg_id"].duplicated().any():
        ids = int(frame.loc[frame.ecg_id.duplicated(keep=False), "ecg_id"].nunique())
        raise ValueError(f"{path.name} contains {ids} duplicated ecg_id values")
    return frame


def load_cohort(data_dir: str | Path) -> pd.DataFrame:
    """Join the four canonical input files strictly by ``ecg_id``."""
    root = Path(data_dir)
    tables = {name: _read_checked(root / name, cols) for name, cols in REQUIRED_FILES.items()}
    db = tables["ptbxl_database.csv"][["ecg_id", "patient_id", "strat_fold"]].copy()
    statements = tables["ptbxl_statements.csv"][["ecg_id", "scp_codes"]].copy()
    statements["target_mi"] = statements["scp_codes"].map(make_mi_target)
    merged = db.merge(statements[["ecg_id", "target_mi"]], on="ecg_id", how="inner", validate="one_to_one")
    merged = merged.merge(tables["12sl_features.csv"], on="ecg_id", how="inner", validate="one_to_one", suffixes=("", "_12sl"))
    merged = merged.merge(tables["unig_features.csv"], on="ecg_id", how="inner", validate="one_to_one", suffixes=("", "_unig"))
    if merged.empty:
        raise ValueError("The four input files have no common ECG identifiers.")
    if merged[["patient_id", "strat_fold"]].isna().any().any():
        raise ValueError("Matched cohort contains missing patient_id or strat_fold values.")
    merged["strat_fold"] = pd.to_numeric(merged["strat_fold"], errors="raise").astype(int)
    if not set(merged["strat_fold"].unique()).issubset(set(range(1, 11))):
        raise ValueError("Unexpected PTB-XL strat_fold value; expected values 1 through 10.")
    return merged.sort_values("ecg_id").reset_index(drop=True)


def numeric_feature_columns(frame: pd.DataFrame) -> list[str]:
    excluded = {"ecg_id", "patient_id", "strat_fold", "target_mi", "scp_codes"}
    columns = frame.drop(columns=[c for c in excluded if c in frame.columns])
    return columns.select_dtypes(include=[np.number]).columns.tolist()


def official_masks(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    folds = frame["strat_fold"].to_numpy()
    masks = (np.isin(folds, np.arange(1, 9)), folds == 9, folds == 10)
    if any(not mask.any() for mask in masks):
        raise ValueError("Expected non-empty train folds 1-8, validation fold 9, and test fold 10.")
    groups = frame["patient_id"].to_numpy()
    names = ("train", "validation", "test")
    patient_sets = [set(groups[mask]) for mask in masks]
    overlaps = {
        "train_validation": len(patient_sets[0] & patient_sets[1]),
        "train_test": len(patient_sets[0] & patient_sets[2]),
        "validation_test": len(patient_sets[1] & patient_sets[2]),
    }
    if any(overlaps.values()):
        raise ValueError(f"Patient leakage detected across official partitions: {overlaps}")
    return masks


def split_audit(frame: pd.DataFrame) -> dict:
    masks = official_masks(frame)
    groups = frame["patient_id"].to_numpy()
    return {
        "n_records": int(len(frame)),
        "n_patients": int(pd.Series(groups).nunique()),
        "records_by_partition": {name: int(mask.sum()) for name, mask in zip(("train", "validation", "test"), masks)},
        "patients_by_partition": {name: int(pd.Series(groups[mask]).nunique()) for name, mask in zip(("train", "validation", "test"), masks)},
        "patient_overlap": {"train_validation": 0, "train_test": 0, "validation_test": 0},
        "target_definition": "SCP-ECG code includes AMI, IMI, LMI, or PMI",
    }
