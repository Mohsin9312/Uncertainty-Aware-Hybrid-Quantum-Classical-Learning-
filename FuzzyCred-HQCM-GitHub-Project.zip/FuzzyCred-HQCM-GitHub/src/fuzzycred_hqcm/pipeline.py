"""Leakage-controlled training and evaluation orchestration."""
from __future__ import annotations
import json
from pathlib import Path
import random
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, mutual_info_classif, VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from sklearn.preprocessing import RobustScaler, StandardScaler
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from .data import load_cohort, numeric_feature_columns, official_masks, split_audit
from .fuzzycred import FuzzyCredMetaLearner
from .metrics import binary_metrics
from .quantum import fit_vqc, predict_vqc


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def _preprocess_fit(X_train: pd.DataFrame, y_train: np.ndarray, n_features: int, seed: int):
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    Xt = imputer.fit_transform(X_train.replace([np.inf, -np.inf], np.nan))
    variance = VarianceThreshold(threshold=0.0)
    Xt = variance.fit_transform(Xt)
    k = min(n_features, Xt.shape[1])
    selector = SelectKBest(score_func=lambda X, y: mutual_info_classif(X, y, random_state=seed), k=k)
    Xs = selector.fit_transform(Xt, y_train)
    classical_scaler = RobustScaler()
    Xc = classical_scaler.fit_transform(Xs)
    quantum_scaler = StandardScaler()
    Xq = quantum_scaler.fit_transform(Xt)
    pca = PCA(n_components=4, random_state=seed)
    Zq = pca.fit_transform(Xq)
    # Explicit deterministic mapping from PCA coordinates to rotation angles.
    angles = np.clip(Zq / 3.0, -1.0, 1.0) * np.pi
    state = {"imputer": imputer, "variance": variance, "selector": selector,
             "classical_scaler": classical_scaler, "quantum_scaler": quantum_scaler, "pca": pca,
             "n_input_features": int(X_train.shape[1]), "selected_count": int(k)}
    return state, Xc, angles


def _preprocess_transform(state: dict, X: pd.DataFrame):
    Xt = state["imputer"].transform(X.replace([np.inf, -np.inf], np.nan))
    Xt = state["variance"].transform(Xt)
    Xs = state["selector"].transform(Xt)
    Xc = state["classical_scaler"].transform(Xs)
    Xq = state["quantum_scaler"].transform(Xt)
    Zq = state["pca"].transform(Xq)
    angles = np.clip(Zq / 3.0, -1.0, 1.0) * np.pi
    return Xc, angles


def _new_lgbm(seed: int) -> LGBMClassifier:
    return LGBMClassifier(objective="binary", n_estimators=700, learning_rate=0.03,
        num_leaves=31, max_depth=-1, min_child_samples=35, colsample_bytree=0.85,
        subsample=0.85, subsample_freq=1, reg_lambda=2.0, random_state=seed,
        n_jobs=-1, verbosity=-1)


def run_experiment(data_dir: str | Path, output_dir: str | Path, *, seed: int = 2026,
                   n_features: int = 128, inner_folds: int = 5, run_quantum: bool = True,
                   vqc_layers: int = 2, vqc_epochs: int = 200, vqc_batch_size: int = 256,
                   vqc_lr: float = 0.03, device: str = "cpu") -> dict:
    """Train the base branches, fit FuzzyCred on grouped OOF predictions, and evaluate once."""
    seed_all(seed)
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    frame = load_cohort(data_dir)
    masks = official_masks(frame)
    audit = split_audit(frame)
    (out / "patient_split_audit.json").write_text(json.dumps(audit, indent=2))
    feature_cols = numeric_feature_columns(frame)
    if not feature_cols:
        raise ValueError("No numeric predictors found in the joined feature tables.")
    X = frame[feature_cols].copy()
    y = frame["target_mi"].to_numpy(dtype=int)
    patient = frame["patient_id"].to_numpy()
    train_mask, val_mask, test_mask = masks
    train_indices = np.flatnonzero(train_mask)
    X_train, y_train, g_train = X.iloc[train_indices], y[train_indices], patient[train_indices]
    X_val, y_val = X.loc[val_mask], y[val_mask]
    X_test, y_test = X.loc[test_mask], y[test_mask]

    # Grouped OOF probabilities are the only observations used to fit the stacker.
    unique_groups = np.unique(g_train)
    n_splits = min(inner_folds, len(unique_groups))
    if n_splits < 2:
        raise ValueError("At least two unique training patients are required for grouped OOF stacking.")
    splitter = GroupKFold(n_splits=n_splits)
    oof_lgb = np.full(len(y_train), np.nan)
    oof_vqc = np.full(len(y_train), np.nan) if run_quantum else None
    inner_records = []
    for fold_idx, (itr, iva) in enumerate(splitter.split(X_train, y_train, groups=g_train), start=1):
        if set(g_train[itr]) & set(g_train[iva]):
            raise RuntimeError("Patient overlap detected inside a stacking fold.")
        state, Xci, Xqi = _preprocess_fit(X_train.iloc[itr], y_train[itr], n_features, seed + fold_idx)
        Xcv, Xqv = _preprocess_transform(state, X_train.iloc[iva])
        lgb = _new_lgbm(seed + fold_idx)
        lgb.fit(Xci, y_train[itr], callbacks=[log_evaluation(0)])
        oof_lgb[iva] = lgb.predict_proba(Xcv)[:, 1]
        record = {"inner_fold": fold_idx, "train_records": int(len(itr)), "heldout_records": int(len(iva)),
                  "train_patients": int(pd.Series(g_train[itr]).nunique()),
                  "heldout_patients": int(pd.Series(g_train[iva]).nunique())}
        if run_quantum:
            # Reserve a patient-disjoint subset of the inner-training fold for
            # early stopping. The OOF fold labels are never used to select epochs.
            inner_groups = g_train[itr]
            splitter_stop = GroupShuffleSplit(n_splits=1, test_size=0.15, random_state=seed + fold_idx)
            fit_local, stop_local = next(splitter_stop.split(X_train.iloc[itr], y_train[itr], groups=inner_groups))
            if len(np.unique(y_train[itr][fit_local])) < 2 or len(np.unique(y_train[itr][stop_local])) < 2:
                raise ValueError("Grouped VQC early-stopping split must contain both target classes in each partition.")
            if set(inner_groups[fit_local]) & set(inner_groups[stop_local]):
                raise RuntimeError("Patient overlap detected in the VQC early-stopping split.")
            qstate, Xq_fit_c, Xq_fit = _preprocess_fit(X_train.iloc[itr].iloc[fit_local], y_train[itr][fit_local], n_features, seed + fold_idx)
            _, Xq_stop = _preprocess_transform(qstate, X_train.iloc[itr].iloc[stop_local])
            _, Xq_oof = _preprocess_transform(qstate, X_train.iloc[iva])
            qmodel, qinfo = fit_vqc(Xq_fit, y_train[itr][fit_local], Xq_stop, y_train[itr][stop_local],
                seed=seed + fold_idx, n_layers=vqc_layers, epochs=vqc_epochs,
                batch_size=vqc_batch_size, learning_rate=vqc_lr, device=device)
            oof_vqc[iva] = predict_vqc(qmodel, Xq_oof, device=device)
            record.update(qinfo)
            record["vqc_early_stop_patients"] = int(pd.Series(inner_groups[stop_local]).nunique())
        inner_records.append(record)
    if not np.isfinite(oof_lgb).all() or (run_quantum and not np.isfinite(oof_vqc).all()):
        raise RuntimeError("OOF predictions contain missing values; refusing to fit the meta-learner.")

    # Refit preprocessing and branch estimators on all training folds only.
    state, Xct, Xqt = _preprocess_fit(X_train, y_train, n_features, seed)
    Xcv, Xqv = _preprocess_transform(state, X_val)
    Xcx, Xqx = _preprocess_transform(state, X_test)
    final_lgb = _new_lgbm(seed)
    final_lgb.fit(Xct, y_train, callbacks=[log_evaluation(0)])
    p_lgb_val, p_lgb_test = final_lgb.predict_proba(Xcv)[:, 1], final_lgb.predict_proba(Xcx)[:, 1]

    if run_quantum:
        qmodel, qinfo = fit_vqc(Xqt, y_train, Xqv, y_val, seed=seed, n_layers=vqc_layers,
            epochs=vqc_epochs, batch_size=vqc_batch_size, learning_rate=vqc_lr, device=device)
        p_q_val, p_q_test = predict_vqc(qmodel, Xqv, device=device), predict_vqc(qmodel, Xqx, device=device)
        meta = FuzzyCredMetaLearner(random_state=seed).fit(oof_lgb, oof_vqc, y_train)
        p_meta_val, p_meta_test = meta.predict_proba(p_lgb_val, p_q_val), meta.predict_proba(p_lgb_test, p_q_test)
        predictions = pd.DataFrame({"ecg_id": frame.loc[test_mask, "ecg_id"].to_numpy(),
            "patient_id": patient[test_mask], "y_true": y_test, "lightgbm_probability": p_lgb_test,
            "vqc_probability": p_q_test, "fuzzycred_probability": p_meta_test})
        metrics = [{"model": name, **binary_metrics(y_test, prob)} for name, prob in
                   (("LightGBM", p_lgb_test), ("4-qubit VQC", p_q_test), ("FuzzyCred-HQCM", p_meta_test))]
        np.savez_compressed(out / "validation_probabilities.npz", y_true=y_val, lightgbm=p_lgb_val,
                            vqc=p_q_val, fuzzycred=p_meta_val, ecg_id=frame.loc[val_mask, "ecg_id"].to_numpy(),
                            patient_id=patient[val_mask])
        np.savez_compressed(out / "test_probabilities.npz", y_true=y_test, lightgbm=p_lgb_test,
                            vqc=p_q_test, fuzzycred=p_meta_test, ecg_id=frame.loc[test_mask, "ecg_id"].to_numpy(),
                            patient_id=patient[test_mask])
        qinfo["architecture"] = {"qubits": 4, "layers": vqc_layers, "encoding": "RY/RZ angle encoding",
                                  "entanglement": "ring CNOT", "simulator": "PennyLane default.qubit"}
        (out / "vqc_training_info.json").write_text(json.dumps(qinfo, indent=2))
        try:
            import torch
            torch.save(qmodel.state_dict(), out / "vqc_state_dict.pt")
        except Exception as exc:
            (out / "model_save_warning.txt").write_text(str(exc))
    else:
        predictions = pd.DataFrame({"ecg_id": frame.loc[test_mask, "ecg_id"].to_numpy(),
            "patient_id": patient[test_mask], "y_true": y_test, "lightgbm_probability": p_lgb_test})
        metrics = [{"model": "LightGBM", **binary_metrics(y_test, p_lgb_test)}]
        p_meta_val = p_meta_test = None

    pd.DataFrame(metrics).to_csv(out / "test_metrics.csv", index=False)
    predictions.to_csv(out / "test_predictions.csv", index=False)
    pd.DataFrame(inner_records).to_csv(out / "inner_grouped_cv_audit.csv", index=False)
    selected = state["selector"].get_support(indices=True)
    retained = state["variance"].get_support(indices=True)
    original_after_variance = np.asarray(feature_cols)[retained]
    selected_names = set(original_after_variance[selected])
    pd.DataFrame({"feature": feature_cols, "selected_by_mutual_information": [int(c in selected_names) for c in feature_cols]}).to_csv(out / "feature_manifest.csv", index=False)
    config = {"seed": seed, "target": "SCP-ECG codes AMI/IMI/LMI/PMI", "outer_split": "PTB-XL folds 1-8 train, 9 validation, 10 test",
        "n_records": len(frame), "n_patients": int(pd.Series(patient).nunique()), "n_numeric_features": len(feature_cols),
        "selected_features": int(state["selected_count"]), "inner_folds": n_splits, "inner_cv_grouping": "patient_id via GroupKFold",
        "quantum_branch_enabled": bool(run_quantum), "vqc_layers": vqc_layers if run_quantum else None,
        "vqc_epochs_max": vqc_epochs if run_quantum else None,
        "fuzzycred_meta_features": "branch probabilities; low/medium/high fuzzy memberships; disagreement; confidence",
        "note": "Metrics are generated by this repository's documented pipeline; they are not copied from historical manuscript tables."}
    (out / "run_config.json").write_text(json.dumps(config, indent=2))
    return {"audit": audit, "config": config, "metrics": metrics}
