"""Command-line interface."""
from __future__ import annotations
import argparse
import json
from .pipeline import run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Train and evaluate FuzzyCred-HQCM on PTB-XL+ feature tables.")
    parser.add_argument("--data-dir", required=True, help="Directory containing the four required CSV files.")
    parser.add_argument("--output-dir", default="results", help="Directory for predictions, metrics and audit files.")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--features", type=int, default=128, help="Number of MI-selected features for LightGBM.")
    parser.add_argument("--inner-folds", type=int, default=5, help="Patient-grouped OOF folds used to train FuzzyCred.")
    parser.add_argument("--classical-only", action="store_true", help="Run the LightGBM baseline without the VQC or stacker.")
    parser.add_argument("--vqc-layers", type=int, default=2)
    parser.add_argument("--vqc-epochs", type=int, default=200)
    parser.add_argument("--vqc-batch-size", type=int, default=256)
    parser.add_argument("--vqc-learning-rate", type=float, default=0.03)
    parser.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    args = parser.parse_args()
    result = run_experiment(args.data_dir, args.output_dir, seed=args.seed, n_features=args.features,
        inner_folds=args.inner_folds, run_quantum=not args.classical_only, vqc_layers=args.vqc_layers,
        vqc_epochs=args.vqc_epochs, vqc_batch_size=args.vqc_batch_size,
        vqc_lr=args.vqc_learning_rate, device=args.device)
    print(json.dumps(result, indent=2))
