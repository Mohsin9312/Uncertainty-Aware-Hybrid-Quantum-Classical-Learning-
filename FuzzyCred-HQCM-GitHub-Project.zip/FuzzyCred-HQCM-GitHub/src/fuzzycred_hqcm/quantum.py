"""Four-qubit variational quantum classifier using PennyLane and PyTorch."""
from __future__ import annotations
import numpy as np


def build_vqc(n_qubits: int = 4, n_layers: int = 2, seed: int = 2026):
    """Build a differentiable state-vector VQC with RY/RZ encoding and CNOT ring."""
    try:
        import pennylane as qml
        import torch
        from torch import nn
    except ImportError as exc:
        raise RuntimeError("Install the optional dependencies with `pip install -e '.[quantum]'`.") from exc
    if n_qubits != 4:
        raise ValueError("This project specifies a four-qubit circuit.")
    if n_layers < 1:
        raise ValueError("n_layers must be at least 1.")
    torch.manual_seed(seed)
    device = qml.device("default.qubit", wires=n_qubits, shots=None)
    shapes = {"weights": (n_layers, n_qubits, 2)}

    @qml.qnode(device, interface="torch", diff_method="backprop")
    def circuit(inputs, weights):
        for q in range(n_qubits):
            qml.RY(inputs[q], wires=q)
            qml.RZ(inputs[q], wires=q)
        for layer in range(n_layers):
            for q in range(n_qubits):
                qml.RY(weights[layer, q, 0], wires=q)
                qml.RZ(weights[layer, q, 1], wires=q)
            for q in range(n_qubits):
                qml.CNOT(wires=[q, (q + 1) % n_qubits])
        return [qml.expval(qml.PauliZ(q)) for q in range(n_qubits)]

    quantum_layer = qml.qnn.TorchLayer(circuit, shapes)

    class VQCClassifier(nn.Module):
        def __init__(self):
            super().__init__()
            self.quantum = quantum_layer
            self.readout = nn.Linear(n_qubits, 1)

        def forward(self, x):
            return self.readout(self.quantum(x)).squeeze(-1)

    return VQCClassifier()


def fit_vqc(X_train, y_train, X_val, y_val, *, seed=2026, n_layers=2,
            epochs=200, batch_size=256, learning_rate=0.03, patience=20, device="cpu"):
    """Fit with validation-loss early stopping and restore the best checkpoint."""
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = build_vqc(4, n_layers, seed).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.BCEWithLogitsLoss()
    dataset = TensorDataset(torch.as_tensor(X_train, dtype=torch.float32), torch.as_tensor(y_train, dtype=torch.float32))
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, generator=torch.Generator().manual_seed(seed))
    xv = torch.as_tensor(X_val, dtype=torch.float32, device=device)
    yv = torch.as_tensor(y_val, dtype=torch.float32, device=device)
    best_loss, best_state, best_epoch, wait = float("inf"), None, 0, 0
    for epoch in range(1, epochs + 1):
        model.train()
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss_fn(model(xb), yb).backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            loss = float(loss_fn(model(xv), yv).item())
        if loss < best_loss - 1e-6:
            best_loss, best_epoch, wait = loss, epoch, 0
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
        else:
            wait += 1
        if wait >= patience:
            break
    if best_state is None:
        raise RuntimeError("VQC training did not produce a valid checkpoint.")
    model.load_state_dict(best_state)
    return model, {"best_epoch": best_epoch, "best_validation_loss": best_loss}


def predict_vqc(model, X, *, batch_size=256, device="cpu") -> np.ndarray:
    import torch
    model.eval()
    output = []
    with torch.no_grad():
        for start in range(0, len(X), batch_size):
            xb = torch.as_tensor(X[start:start + batch_size], dtype=torch.float32, device=device)
            output.extend(torch.sigmoid(model(xb)).detach().cpu().numpy().tolist())
    return np.asarray(output, dtype=float)
