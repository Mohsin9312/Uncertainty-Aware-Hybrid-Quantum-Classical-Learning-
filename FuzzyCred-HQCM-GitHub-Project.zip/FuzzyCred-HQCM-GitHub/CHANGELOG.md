# Changelog

## 1.0.0 — 2026-10-13

- Added installable Python package and CLI.
- Added identifier-validated multi-source cohort loader and outer patient-fold audit.
- Added patient-grouped OOF stacking and inner-fold audit.
- Added LightGBM and optional four-qubit PennyLane VQC branches.
- Added fuzzy membership features and supervised FuzzyCred meta-readout.
- Added metrics, aligned validation/test prediction exports, tests, and GitHub Actions workflow.
