# Contributing

1. Open an issue describing the methodological change or bug.
2. Add or update tests for behavior changes.
3. Run `pytest -q` and `python -m compileall -q src tests` before submitting a pull request.
4. Do not commit patient-level data, trained weights, credentials, or restricted source-feature tables.
5. Any change to target definition, preprocessing, split logic, or the FuzzyCred meta-learner must be documented in `docs/METHOD_SPECIFICATION.md` and accompanied by a versioned experiment configuration.
