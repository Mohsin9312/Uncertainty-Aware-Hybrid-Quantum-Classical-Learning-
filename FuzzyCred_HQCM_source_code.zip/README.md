# FuzzyCred-HQCM ECG experiment: reproducible reference source

## Important provenance note

This package is a **reference reimplementation based on the methods and data schema documented in the manuscript**. It is not the original source code used to generate every historical result in the manuscript. The manuscript itself records that the exact original FuzzyCred meta-learner specification, full hyperparameter logs, complete seed logs, and row-aligned predictions were not available. It would be inaccurate to claim that this newly authored code is the exact historical implementation.

The package provides:
- explicit `ecg_id` joins (never relies on row order);
- MI target construction from PTB-XL SCP codes AMI/IMI/LMI/PMI;
- official PTB-XL folds 1–8 for training, fold 9 for validation, fold 10 for test;
- an outer-fold patient-overlap audit;
- training-only median imputation, mutual-information feature selection, scaling, and PCA;
- LightGBM baseline;
- an optional four-qubit PennyLane VQC with RY/RZ encoding and a ring CNOT entangling layer;
- an explicitly labelled reference probability blend (not the undocumented historical FuzzyCred meta-learner);
- test metrics, row-aligned predictions, feature manifest, and run configuration output.

## Required input files

Put these files in one folder (or rename your available files to these canonical names):

1. `ptbxl_database.csv` — columns `ecg_id`, `patient_id`, `strat_fold`
2. `ptbxl_statements.csv` — columns `ecg_id`, `scp_codes`
3. `12sl_features.csv` — must contain `ecg_id` plus numeric features
4. `unig_features.csv` — must contain `ecg_id` plus numeric features

If your 12SL feature file does not contain `ecg_id`, do not join by row order. Obtain the matching ID mapping or create a verified mapping from source metadata first. The script intentionally stops if identifiers are missing.

## Installation

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

For a classical-only baseline run:

```bash
python run_experiment.py --data-dir ./data --output-dir ./results --seed 2026
```

To execute the four-qubit VQC as well (requires PennyLane and PyTorch):

```bash
python run_experiment.py --data-dir ./data --output-dir ./results_vqc \
  --seed 2026 --run-vqc --vqc-layers 2 --vqc-epochs 80 --batch-size 64 --vqc-lr 0.01
```

This uses a state-vector simulator (`default.qubit`), not quantum hardware. VQC training can be slow because the full joined feature table may contain many records.

## Output files

- `patient_split_audit.json`: record and patient counts and outer-fold overlap counts.
- `test_metrics.csv`: test metrics for models actually run.
- `test_predictions.csv`: `ecg_id`, `patient_id`, true labels, and predicted probabilities.
- `feature_manifest.csv`: input feature names and feature-selection indicator.
- `run_config.json`: seed, split definition, feature counts, PCA variance, and run status.
- `vqc_training_info.json`, `pca_variance.json`, `vqc_state_dict.pt`: generated when VQC is run and saving succeeds.

## Metrics

The script reports accuracy, precision, recall/sensitivity, specificity, F1, ROC-AUC, average precision (PR-AUC), Brier score, and confusion-matrix counts. The default classification threshold is 0.50. If a threshold is selected using validation data, document the criterion and apply it once to the locked test set.

## Critical reproducibility and validity notes

1. **Do not claim the reference code reproduces manuscript numbers until it has been run and independently checked.** Exact historical preprocessing and architecture details were not available.
2. The outer fold audit does not verify whether any historical inner stacking cross-validation was patient-grouped. This script's current transparent reference blend does not train a stacking meta-learner.
3. The included `fuzzy_credibility_combine` is a convex probability blend with validation-selected weight. It is explicitly not represented as the original FuzzyCred meta-learner because its exact functional form was not available.
4. This script is designed for an honest re-analysis. It must not be used to tune against the test set or to claim quantum advantage merely because a quantum branch is present.
5. PTB-XL SCP-ECG labels are ECG-derived annotations and are not equivalent to independent clinical adjudication of myocardial infarction using troponin, angiography, or discharge diagnosis.
6. If feature files have overlapping names, the pandas merge adds suffixes. Review `feature_manifest.csv` and `run_config.json` and preserve this mapping in any reported analysis.
7. If any feature source contains derived outputs calculated using the target or post-diagnosis information, exclude those variables before training to prevent leakage.

## Manuscript reporting recommendation

Report the execution environment, package versions, exact seed, selected features, VQC layer count, number of epochs/best validation epoch, split audit, and metrics from `test_metrics.csv`. Do not copy previous manuscript point estimates into a new run unless they are reproduced by this exact pipeline.
