#!/usr/bin/env python3
"""
Reproducible reference implementation for the FuzzyCred-HQCM PTB-XL ECG study.

IMPORTANT:
This is a transparent reimplementation of the methods described in the manuscript,
not the original experiment's exact source code. The manuscript's original
FuzzyCred meta-learner formula, full preprocessing logs, random seeds, and
patient-grouped inner-CV artifacts were not available. Therefore, results from
this code must be treated as a new reproduction run and must not be substituted
for manuscript numbers without running the pipeline and documenting differences.

Primary split: PTB-XL strat_fold 1-8 train, 9 validation, 10 test.
Target: any SCP-ECG code among AMI, IMI, LMI, PMI.
Models: LightGBM classical branch, four-qubit variational quantum circuit (VQC)
branch, and transparent stacking baseline. The default fuzzy credibility
combiner is a clearly specified reference formulation, not a claim to reproduce
the undocumented historical meta-learner.
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import random
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, brier_score_loss,
    confusion_matrix, f1_score, precision_score, recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from lightgbm import LGBMClassifier, early_stopping, log_evaluation

warnings.filterwarnings("ignore", category=UserWarning)
MI_CODES = {"AMI", "IMI", "LMI", "PMI"}


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def parse_scp_codes(value) -> dict:
    """Parse PTB-XL scp_codes stored as a stringified dictionary."""
    if isinstance(value, dict):
        return value
    try:
        parsed = ast.literal_eval(value) if isinstance(value, str) else {}
    except (ValueError, SyntaxError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def mi_label(scp_codes) -> int:
    """Binary ECG-derived endpoint: positive if AMI/IMI/LMI/PMI appears."""
    return int(bool(MI_CODES.intersection(parse_scp_codes(scp_codes).keys())))


def load_and_join(data_dir: Path) -> pd.DataFrame:
    """Join all data by ecg_id; never rely on row order."""
    required = {
        "ptbxl_database.csv": {"ecg_id", "patient_id", "strat_fold"},
        "ptbxl_statements.csv": {"ecg_id", "scp_codes"},
        "12sl_features.csv": {"ecg_id"},
        "unig_features.csv": {"ecg_id"},
    }
    frames = {}
    for filename, columns in required.items():
        path = data_dir / filename
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path}. See README for required filenames and expected columns."
            )
        df = pd.read_csv(path)
        missing = columns.difference(df.columns)
        if missing:
            raise ValueError(f"{filename} is missing required columns: {sorted(missing)}")
        frames[filename] = df

    db = frames["ptbxl_database.csv"][["ecg_id", "patient_id", "strat_fold"]].copy()
    statements = frames["ptbxl_statements.csv"][["ecg_id", "scp_codes"]].copy()
    statements["target_mi"] = statements["scp_codes"].map(mi_label)
    x12 = frames["12sl_features.csv"].copy()
    unig = frames["unig_features.csv"].copy()

    # Drop duplicate identifiers only if duplicates are exact duplicates; otherwise stop.
    for name, df in [("database", db), ("statements", statements), ("12SL", x12), ("Uni-G", unig)]:
        if df["ecg_id"].duplicated().any():
            dup = df.loc[df["ecg_id"].duplicated(keep=False), "ecg_id"].nunique()
            raise ValueError(f"{name} has {dup} duplicated ecg_id values; resolve before analysis.")

    merged = db.merge(statements[["ecg_id", "target_mi"]], on="ecg_id",
                      how="inner", validate="one_to_one")
    merged = merged.merge(x12, on="ecg_id", how="inner", validate="one_to_one",
                          suffixes=("", "_12sl"))
    merged = merged.merge(unig, on="ecg_id", how="inner", validate="one_to_one",
                          suffixes=("_12sl", "_unig"))
    if merged.empty:
        raise ValueError("No matching ECG records. Check identifiers and input files.")
    if merged["patient_id"].isna().any() or merged["strat_fold"].isna().any():
        raise ValueError("Missing patient_id or strat_fold values in matched cohort.")
    return merged


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    excluded = {"ecg_id", "patient_id", "strat_fold", "target_mi", "scp_codes"}
    cols = [c for c in df.columns if c not in excluded]
    numeric = df[cols].select_dtypes(include=[np.number]).columns.tolist()
    if not numeric:
        raise ValueError("No numeric feature columns found after joining.")
    return numeric


def make_lgb(seed: int, n_estimators: int = 600) -> LGBMClassifier:
    return LGBMClassifier(
        objective="binary",
        n_estimators=n_estimators,
        learning_rate=0.03,
        num_leaves=31,
        min_child_samples=35,
        colsample_bytree=0.85,
        subsample=0.85,
        subsample_freq=1,
        reg_lambda=2.0,
        random_state=seed,
        n_jobs=-1,
        verbosity=-1,
    )


def build_vqc(n_qubits: int, n_layers: int, seed: int):
    """
    Construct a differentiable PennyLane VQC using RY/RZ rotations and a ring
    CNOT entangling layer. The 4 PCA scores are angle-encoded onto 4 qubits.
    Returns (torch_model, train_one_epoch_fn, predict_fn).
    """
    try:
        import pennylane as qml
        import torch
        from torch import nn
    except ImportError as exc:
        raise RuntimeError(
            "VQC execution requires PennyLane and PyTorch. Install requirements.txt."
        ) from exc

    torch.manual_seed(seed)
    dev = qml.device("default.qubit", wires=n_qubits, shots=None)
    weight_shapes = {"weights": (n_layers, n_qubits, 2)}

    @qml.qnode(dev, interface="torch", diff_method="backprop")
    def circuit(inputs, weights):
        for q in range(n_qubits):
            qml.RY(inputs[q], wires=q)
            qml.RZ(inputs[q] * 0.5, wires=q)
        for layer in range(n_layers):
            for q in range(n_qubits):
                qml.RY(weights[layer, q, 0], wires=q)
                qml.RZ(weights[layer, q, 1], wires=q)
            for q in range(n_qubits):
                qml.CNOT(wires=[q, (q + 1) % n_qubits])
        return [qml.expval(qml.PauliZ(q)) for q in range(n_qubits)]

    qlayer = qml.qnn.TorchLayer(circuit, weight_shapes)

    class VQCClassifier(nn.Module):
        def __init__(self):
            super().__init__()
            self.quantum = qlayer
            self.head = nn.Linear(n_qubits, 1)

        def forward(self, x):
            qout = self.quantum(x)
            return self.head(qout).squeeze(-1)

    model = VQCClassifier()
    return model


def train_vqc(X_train, y_train, X_val, y_val, seed: int, n_layers: int,
              epochs: int, batch_size: int, learning_rate: float, device: str):
    """Train VQC using training data; select epoch using validation loss."""
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset

    seed_everything(seed)
    torch.manual_seed(seed)
    model = build_vqc(n_qubits=4, n_layers=n_layers, seed=seed).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    loss_fn = nn.BCEWithLogitsLoss()

    def tensor_data(X, y):
        return TensorDataset(torch.tensor(X, dtype=torch.float32),
                             torch.tensor(y, dtype=torch.float32))

    loader = DataLoader(tensor_data(X_train, y_train), batch_size=batch_size,
                        shuffle=True, generator=torch.Generator().manual_seed(seed))
    Xv = torch.tensor(X_val, dtype=torch.float32, device=device)
    yv = torch.tensor(y_val, dtype=torch.float32, device=device)
    best_state, best_loss, best_epoch, patience = None, float("inf"), 0, 0
    for epoch in range(1, epochs + 1):
        model.train()
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            val_loss = float(loss_fn(model(Xv), yv).item())
        if val_loss < best_loss - 1e-5:
            best_loss, best_epoch, patience = val_loss, epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience += 1
        if patience >= 20:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {"best_epoch": best_epoch, "best_val_loss": best_loss}


def vqc_predict(model, X, device: str, batch_size: int = 256) -> np.ndarray:
    import torch
    model.eval()
    outs = []
    with torch.no_grad():
        for start in range(0, len(X), batch_size):
            xb = torch.tensor(X[start:start + batch_size], dtype=torch.float32, device=device)
            outs.extend(torch.sigmoid(model(xb)).detach().cpu().numpy().tolist())
    return np.asarray(outs)


def metrics(y_true, prob, threshold=0.5) -> dict:
    pred = (np.asarray(prob) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        "threshold": float(threshold),
        "n": int(len(y_true)),
        "positives": int(np.sum(y_true)),
        "accuracy": float(accuracy_score(y_true, pred)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall_sensitivity": float(recall_score(y_true, pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if (tn + fp) else float("nan"),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, prob)) if len(np.unique(y_true)) == 2 else float("nan"),
        "pr_auc_average_precision": float(average_precision_score(y_true, prob)),
        "brier": float(brier_score_loss(y_true, prob)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def fuzzy_credibility_combine(p_classical, p_quantum, alpha=0.5):
    """
    Transparent baseline combiner for a reproducible reference implementation.
    This convex probability blend is NOT the undocumented historical FuzzyCred
    meta-learner. Use a learned meta-learner trained on patient-grouped OOF
    predictions for a faithful stacking experiment.
    """
    p_classical = np.asarray(p_classical, dtype=float)
    p_quantum = np.asarray(p_quantum, dtype=float)
    return alpha * p_classical + (1.0 - alpha) * p_quantum


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, help="Folder containing four CSV input files.")
    parser.add_argument("--output-dir", default="results")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--vqc-layers", type=int, default=2)
    parser.add_argument("--vqc-epochs", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--vqc-lr", type=float, default=0.01)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--run-vqc", action="store_true", help="Run the PennyLane VQC (computationally slower).")
    parser.add_argument("--classical-features", type=int, default=128)
    args = parser.parse_args()

    seed_everything(args.seed)
    data_dir = Path(args.data_dir)
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    df = load_and_join(data_dir)
    feature_cols = get_feature_columns(df)
    X = df[feature_cols].replace([np.inf, -np.inf], np.nan)
    y = df["target_mi"].astype(int).to_numpy()
    fold = df["strat_fold"].astype(int).to_numpy()
    groups = df["patient_id"].to_numpy()

    train_mask = np.isin(fold, np.arange(1, 9))
    val_mask = fold == 9
    test_mask = fold == 10
    if not (train_mask.any() and val_mask.any() and test_mask.any()):
        raise ValueError("Expected PTB-XL strat_fold partitions 1–8, 9, and 10.")

    # Leakage audit for the official outer fold split.
    partition_patients = {
        "train": set(groups[train_mask]),
        "validation": set(groups[val_mask]),
        "test": set(groups[test_mask]),
    }
    audit = {
        "n_records": int(len(df)),
        "n_patients": int(pd.Series(groups).nunique()),
        "records_by_partition": {
            "train": int(train_mask.sum()), "validation": int(val_mask.sum()),
            "test": int(test_mask.sum()),
        },
        "patient_overlap": {
            "train_validation": len(partition_patients["train"] & partition_patients["validation"]),
            "train_test": len(partition_patients["train"] & partition_patients["test"]),
            "validation_test": len(partition_patients["validation"] & partition_patients["test"]),
        },
        "note": "This audits outer folds only; inner stacking CV must also be patient-grouped."
    }
    (outdir / "patient_split_audit.json").write_text(json.dumps(audit, indent=2))

    Xtr_raw, Xva_raw, Xte_raw = X.loc[train_mask], X.loc[val_mask], X.loc[test_mask]
    ytr, yva, yte = y[train_mask], y[val_mask], y[test_mask]
    gtr = groups[train_mask]

    # All learned preprocessing is fitted on training folds only.
    imputer = SimpleImputer(strategy="median")
    Xtr_imp = imputer.fit_transform(Xtr_raw)
    Xva_imp = imputer.transform(Xva_raw)
    Xte_imp = imputer.transform(Xte_raw)

    # Classical branch: select 128 variables using training labels only.
    k = min(args.classical_features, Xtr_imp.shape[1])
    selector = SelectKBest(score_func=mutual_info_classif, k=k)
    Xtr_sel = selector.fit_transform(Xtr_imp, ytr)
    Xva_sel = selector.transform(Xva_imp)
    Xte_sel = selector.transform(Xte_imp)

    lgb = make_lgb(args.seed)
    lgb.fit(Xtr_sel, ytr, eval_set=[(Xva_sel, yva)], eval_metric="auc",
            callbacks=[early_stopping(40, verbose=False), log_evaluation(0)])
    p_lgb_val = lgb.predict_proba(Xva_sel)[:, 1]
    p_lgb_test = lgb.predict_proba(Xte_sel)[:, 1]

    # Quantum input projection: scaler and PCA fitted on training partition only.
    scaler = StandardScaler()
    Xtr_scaled = scaler.fit_transform(Xtr_imp)
    Xva_scaled = scaler.transform(Xva_imp)
    Xte_scaled = scaler.transform(Xte_imp)
    pca = PCA(n_components=4, random_state=args.seed)
    Ztr = pca.fit_transform(Xtr_scaled)
    Zva = pca.transform(Xva_scaled)
    Zte = pca.transform(Xte_scaled)
    # Bounded angle encoding; scaling is fixed and documented, not tuned on test.
    def encode_angles(Z):
        return np.clip(Z / 2.0, -np.pi, np.pi)
    Qtr, Qva, Qte = encode_angles(Ztr), encode_angles(Zva), encode_angles(Zte)

    result_rows = [
        {"model": "LightGBM", **metrics(yte, p_lgb_test)}
    ]
    prediction_data = pd.DataFrame({
        "ecg_id": df.loc[test_mask, "ecg_id"].to_numpy(),
        "patient_id": groups[test_mask],
        "y_true": yte,
        "lightgbm_probability": p_lgb_test,
    })

    if args.run_vqc:
        vqc, training_info = train_vqc(
            Qtr, ytr, Qva, yva, seed=args.seed, n_layers=args.vqc_layers,
            epochs=args.vqc_epochs, batch_size=args.batch_size,
            learning_rate=args.vqc_lr, device=args.device
        )
        p_vqc_val = vqc_predict(vqc, Qva, args.device)
        p_vqc_test = vqc_predict(vqc, Qte, args.device)
        result_rows.append({"model": "4-qubit VQC", **metrics(yte, p_vqc_test)})
        prediction_data["vqc_probability"] = p_vqc_test

        # Validation-only choose blend coefficient. Do not tune on test data.
        best_alpha, best_val_auc = 0.5, -np.inf
        for alpha in np.linspace(0, 1, 101):
            candidate = alpha * p_lgb_val + (1 - alpha) * p_vqc_val
            auc = roc_auc_score(yva, candidate)
            if auc > best_val_auc:
                best_val_auc, best_alpha = float(auc), float(alpha)
        p_blend_test = fuzzy_credibility_combine(p_lgb_test, p_vqc_test, best_alpha)
        result_rows.append({
            "model": f"Probability blend (alpha={best_alpha:.2f}; reference, not historical FuzzyCred)",
            **metrics(yte, p_blend_test)
        })
        prediction_data["reference_blend_probability"] = p_blend_test
        (outdir / "vqc_training_info.json").write_text(json.dumps(training_info, indent=2))
        (outdir / "pca_variance.json").write_text(json.dumps(
            {"explained_variance_ratio": pca.explained_variance_ratio_.tolist(),
             "sum_first_four_components": float(pca.explained_variance_ratio_.sum())}, indent=2
        ))

        try:
            import torch
            import pennylane as qml
            torch.save(vqc.state_dict(), outdir / "vqc_state_dict.pt")
        except Exception as exc:
            print(f"Warning: VQC weights not saved: {exc}")

    pd.DataFrame(result_rows).to_csv(outdir / "test_metrics.csv", index=False)
    prediction_data.to_csv(outdir / "test_predictions.csv", index=False)
    pd.DataFrame({
        "feature": feature_cols,
        "selected_by_mi": [int(c in set(np.array(feature_cols)[selector.get_support(indices=True)]))
                           if len(feature_cols) == selector.get_support().shape[0] else 0
                           for c in feature_cols]
    }).to_csv(outdir / "feature_manifest.csv", index=False)

    run_info = {
        "seed": args.seed,
        "target": "positive if SCP code AMI, IMI, LMI, or PMI",
        "outer_split": "folds 1-8 train; fold 9 validation; fold 10 test",
        "n_records": int(len(df)),
        "n_patients": int(pd.Series(groups).nunique()),
        "n_numeric_features_before_selection": int(len(feature_cols)),
        "classical_selected_features": int(k),
        "pca_components": 4,
        "pca_explained_variance_ratio": pca.explained_variance_ratio_.tolist(),
        "lgbm_best_iteration": int(lgb.best_iteration_ or lgb.n_estimators),
        "vqc_run": bool(args.run_vqc),
        "reproducibility_status": "Reference reimplementation; not the unavailable original source code."
    }
    (outdir / "run_config.json").write_text(json.dumps(run_info, indent=2))
    print(json.dumps(run_info, indent=2))
    print("\nTest metrics:")
    print(pd.DataFrame(result_rows).to_string(index=False))


if __name__ == "__main__":
    main()
